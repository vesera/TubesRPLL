﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class SettingsMenu : MonoBehaviour
{
    private float musicVolume = 1f;
    public AudioSource audioSource;

    void Start(){
        if(audioSource == null){
            Debug.LogError(this, this);
        }
        audioSource.volume = musicVolume;
    }

    void Update(){
        audioSource.volume = musicVolume;
    }

    public void updateVolume(float volume){
        musicVolume = volume;
    }
}
