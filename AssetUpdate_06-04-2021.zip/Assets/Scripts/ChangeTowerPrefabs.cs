﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.SceneManagement;
using UnityEngine;

public class ChangeTowerPrefabs : MonoBehaviour
{
    public GameObject towerLeft;
    public GameObject towerRight;
    public GameObject towerUp;
    public GameObject towerDown;

  

    public void ChangePrefabs(Vector3 newposision,float angle)
    {
        transform.position = newposision;
        if (angle <= -45 && angle <= 45)
        {
            
            GameObject towerA =  Instantiate(towerRight, newposision, Quaternion.Euler(0,0,0));
            print("TowerA");
        }
        else if(angle > 45 && angle< 135 ) 
        {
            GameObject towerB = Instantiate(towerUp, newposision,Quaternion.Euler(0,0,0));
            print("TowerB");
        } 
        else if(angle >= 135 && angle<= -135 ) 
        {
            GameObject towerC = Instantiate(towerLeft, newposision, Quaternion.Euler(0, 0, 0));
            print("TowerC");
        } 
        else if (angle> -135 && angle< -45 )
        {
            GameObject towerD = Instantiate(towerDown, newposision, Quaternion.Euler(0, 0, 0));
            print("TowerD");
        }
    }
  
}
