﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class GameOver : MonoBehaviour
{
    public void EndGame()
    {
        Debug.Log("Game Over");
        Invoke("Restart", 0.3f);
    }
    void Restart()
    {
        
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        print("Restart");

    }   
}
