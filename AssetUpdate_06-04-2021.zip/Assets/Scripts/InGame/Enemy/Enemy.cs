﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField]
    public float enemyHealth;
    [SerializeField]
    public float movementSpeed;
    [SerializeField]
    private int killReward; // uang yang di dapat ketika enemy ini di kill
    [SerializeField]
    private int damage; // damege yang di terima jika musuh samapai di akhir
    private GameObject targetTile;


    private void Awake()
    {
        Enemies.enemies.Add(gameObject);
    }

    private void Start()
    {
        initializeEnemy();
    }

    private void initializeEnemy()
    {
        targetTile = TextToMap.startTile;
    }

    public void takeDamage(float amount)
    {
        enemyHealth -= amount;

        if (enemyHealth <= 0)
        {
            die();
        }
    }

    private void die()
    {
        SideMenuScript.getGold(killReward);
        Enemies.enemies.Remove(gameObject);
        Destroy(gameObject.transform.gameObject);
    }
    private void moveEnemy()
    {
        if (gameObject != null)
        {
            
            gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, targetTile.transform.position, movementSpeed * Time.deltaTime);
        }
        
    }

    private void checkPosition()
    {
        int currentIndex = TextToMap.pathTile.IndexOf(targetTile);
        if (targetTile != null && targetTile != TextToMap.endTile)
        {
            float distance = (transform.position - targetTile.transform.position).magnitude;
            
            if (distance < 0.001f)
            {
                Debug.Log("PathIndex" + currentIndex);
                if (currentIndex<=14)
                {
                    currentIndex++;
                }
                else if (currentIndex == 15)
                {
                    currentIndex = 42;
                }
                 else if (currentIndex == 42)
                {
                    currentIndex = 38;
                }
                 else if (currentIndex == 38)
                {
                    currentIndex = 24;
                }
                 else if (currentIndex == 24)
                {
                    currentIndex = 16;
                }
                 else if (currentIndex == 16)
                {
                    currentIndex = 32;
                }
                 else if (currentIndex == 32)
                {
                    currentIndex = 37;
                }
                 else if (currentIndex == 37)
                {
                    currentIndex = 43;
                }
                else if (currentIndex >= 43)
                {
                    currentIndex++;
                }
                targetTile = TextToMap.pathTile[currentIndex];
                if (currentIndex == 45)
                {
                    targetTile = TextToMap.endTile;
                }
            }
        }
        if (targetTile != null && targetTile.transform.position == TextToMap.endTile.transform.position)
        {
            StartCoroutine("DamagePlayer");   
        }
        
        
    }
    IEnumerator DamagePlayer()
    {
        if(damage != 0)
        {
            yield return new WaitForSeconds(0.3f);
            SideMenuScript.playerHealth(damage);
            die();
        }
    }

    private void Update()
    {
        checkPosition();

        moveEnemy();

        takeDamage(0);


    }



}
