﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Bullet : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("Collision Detected!");
        Destroy(gameObject);
    }

   /* IEnumerator Delay()
    {
        yield return new WaitForSeconds(0.00001f);// nunggu 1 detek buat  add Gameobject lagi
        Destroy(gameObject);
    }*/

    private void Update()
    {
        transform.position += transform.right * 0.3f;//speed bullet
    }
}


