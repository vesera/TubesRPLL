﻿using System.Collections;
using UnityEngine;


public class WaveControl : MonoBehaviour
{
    public GameObject basicEnemy;
    public GameObject heavyEnemy;
    public GameObject fastEnemy;

    public float timeBetweenWaves;
    public float timeBeforeRoundStarts;
    public float timeVariable;
    public float timeMin;
    public float currentTime;



    public bool isRoundGoing;
    public bool isIntermission;
    public bool isStartOfRound;

    public static int rounds ;
    public int round;
    public int maxRound;

    private void Start()
    {
        isRoundGoing = false;
        isIntermission = false;
        isStartOfRound = true;
        Time.timeScale = 1;
        timeMin = Time.time;
        timeVariable = Time.time + timeBeforeRoundStarts;
        round = 1;
        rounds = round;
    }

    private void SpawnEnemies()
    {
        StartCoroutine("ISpawnEnemies");
    }

    IEnumerator ISpawnEnemies()
    {
        for (int i = 0; i < round; i++)
        {
            print("Round:" + i);
            if (round == maxRound)
            {
                GameObject newEnemy = Instantiate(heavyEnemy, TextToMap.startTile.transform.position, Quaternion.identity);
                yield return new WaitForSeconds(1f);// nunggu 1 detek buat  add Gameobject lagi
            }
            else if (round == 2)
            {
                GameObject newEnemy = Instantiate(fastEnemy, TextToMap.startTile.transform.position, Quaternion.identity);
                yield return new WaitForSeconds(1f);// nunggu 1 detek buat  add Gameobject lagi
            }
            else
            {
                GameObject newEnemy = Instantiate(basicEnemy, TextToMap.startTile.transform.position, Quaternion.identity);
                yield return new WaitForSeconds(1f);// nunggu 1 detek buat  add Gameobject lagi
            }
        }
    }

    private void Update()
    {
        currentTime = Time.time - timeMin;
        if (isStartOfRound)
        {
            if(Time.time >= timeVariable)
            {
                Debug.LogWarning("masuk Startround");
                isStartOfRound = false;
                isRoundGoing = true;

                SpawnEnemies();
                return;
            }
        }
        else if (isIntermission)
        {
            if(Time.time >= timeVariable)
            {
                isIntermission = false;
                isRoundGoing = true;

                SpawnEnemies();
            }
        }
        else if (isRoundGoing)
        {
            if (round == maxRound) 
            {
                isIntermission = false;
                isRoundGoing = false;
                isStartOfRound = false;
            }
            if (Enemies.enemies.Count > 0)
            {

            }
            else
            {
                isIntermission = true;
                isRoundGoing = false;

                timeVariable = Time.time + timeBetweenWaves;
                round++;
                rounds = round;
            }
            
        }
    }
}
