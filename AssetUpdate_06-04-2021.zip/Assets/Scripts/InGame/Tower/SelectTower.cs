﻿using UnityEngine;
using UnityEngine.UI;

public class SelectTower : MonoBehaviour
{
    private void Start()
    {
        GameObject.Find("PlacementManager").SetActive(true);
        
    }
    public void Archer()
    {
        FindObjectOfType<PlaceTower>().ArcherTower();
        ToggleButton();
    }
    public void Barbarian()
    {
        FindObjectOfType<PlaceTower>().BarbarianTower();
        ToggleButton();
    }
    public void Wizard()
    {
        FindObjectOfType<PlaceTower>().WizardTower();
        ToggleButton();
    }

    public void ToggleButton()
    {
        GameObject.Find("ArcherTowerButton").GetComponent<Button>().interactable = false;
        GameObject.Find("BarbarianTowerButton").GetComponent<Button>().interactable = false;
        GameObject.Find("WizardTowerButton").GetComponent<Button>().interactable = false;
    }
}
