﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlaceTower : MonoBehaviour
{
    public GameObject basicTowerObject;
    public GameObject meleeTowerObject;
    public GameObject rangeTowerObject;
    public GameObject normalTowerObject;

    private GameObject hoverTile;

    public Camera cam;

    public LayerMask mask;

    public bool isBuilding = false ;

    private Vector2 towerPosition;

    public bool IsDestroyed = false;

    public GameObject newEnemy;
    [SerializeField]
    public int towerPrice;

    private int test = 0;
/*
    public void Start()
    {
        StartBuild();
    }*/

    public Vector2 GetMousePosision()
    {
        return cam.ScreenToWorldPoint(Input.mousePosition);
    }

    public void GetCurrentHoverTile()
    {
        Vector2 mousePosition = GetMousePosision();

        RaycastHit2D hit = Physics2D.Raycast(mousePosition, new Vector2(0, 0), 0.1f, mask, -100, 100);

        if (hit.collider != null)
        {
            if (TextToMap.mapTile.Contains(hit.collider.gameObject))
            {
                if (!TextToMap.pathTile.Contains(hit.collider.gameObject))
                {
                    hoverTile = hit.collider.gameObject;
                }
                // Masih Stacking
                if (!TowerList.towers.Contains(hit.collider.gameObject))
                {
                    hoverTile = hit.collider.gameObject;
                    if (Input.GetMouseButtonDown(0))
                    {
                        isBuilding = true;
                        Debug.Log("Pressed primary button.");
                        towerPosition = GetMousePosision();
                        if (SideMenuScript.gold >= towerPrice)
                        {
                            Debug.Log("Buy Tower");

                            newEnemy = Instantiate(basicTowerObject, towerPosition, Quaternion.identity);
                            
                            Debug.LogWarning("Masuk List Tower" + TowerList.towers[test]);
                            SideMenuScript.useGold(towerPrice);
                            /*isBuilding = false;*/
                            EndBuild();
                            test++;
                        }
                    }
                    else if (Input.GetMouseButtonUp(1))
                    {
                        Destroy(newEnemy);
                        EndBuild();
                    }
                }
            }
        }
      
    }

  

    public void StartBuild()
    {
        isBuilding = true;
        newEnemy = Instantiate(basicTowerObject);
        if(newEnemy.GetComponent<Tower>() != null)
        {
            Destroy(newEnemy.GetComponent<Tower>());
        }


    }
    public void EndBuild()
    {
        isBuilding = false;
        GameObject.Find("ArcherTowerButton").GetComponent<Button>().interactable = true;
        GameObject.Find("BarbarianTowerButton").GetComponent<Button>().interactable = true;
        GameObject.Find("WizardTowerButton").GetComponent<Button>().interactable = true;
    }

    public void BarbarianTower() 
    {
        basicTowerObject = meleeTowerObject;
        StartBuild();
    }
    public void ArcherTower()
    {
        basicTowerObject = rangeTowerObject;
        StartBuild();
    }
    public void WizardTower()
    {
        basicTowerObject = normalTowerObject;
        StartBuild();
    }

    public void Update()
    {
        if(isBuilding == true)
        {
            if(basicTowerObject != null)
            {
                
                GetCurrentHoverTile();
                if(hoverTile != null)
                {
                    newEnemy.transform.position = hoverTile.transform.position;
                }

                
            }
        }

    }
}
