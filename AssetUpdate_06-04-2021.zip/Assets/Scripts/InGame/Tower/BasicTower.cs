﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class BasicTower : Tower
{
    public GameObject bullet;

    protected override void shoot()
    {
        
        base.shoot();


        
        GameObject newbullet = Instantiate(bullet,transform.position,Quaternion.Euler(0,0,angleShoot));
        print("shoot");

    }
}
