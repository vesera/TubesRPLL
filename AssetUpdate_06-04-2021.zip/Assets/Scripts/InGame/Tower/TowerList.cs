﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerList : MonoBehaviour
{
    public static List<GameObject> towers = new List<GameObject>();
}
