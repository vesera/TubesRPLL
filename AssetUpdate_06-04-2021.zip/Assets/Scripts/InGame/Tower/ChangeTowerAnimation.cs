﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeTowerAnimation : MonoBehaviour
{
    public GameObject towerdata;
    public AnimatorOverrideController stand;
    public AnimatorOverrideController Shoot;
    /*public GameObject toweranimation;*/


    private void ChangeAnimation()
    {
        
    }
    private void Update()
    {
/*        ChangeAnimation();*/
        foreach (GameObject tower in TowerList.towers)
        {
            towerdata = tower;
            if (tower != null)
            {
                print("Tower Not null");
                Tower towerangle = towerdata.GetComponent<Tower>();
                Animator animator = towerdata.gameObject.GetComponent<Animator>();

                if (towerangle.angleShoot <= 0)
                {
                    print("Masuk <0 | angle:" + towerangle.angleShoot);
                    animator.runtimeAnimatorController = Resources.Load("Animation/BasicTowerAnimation/Shoot/Front/NormalTowerShootFront") as RuntimeAnimatorController;

                }
                else if (towerangle.angleShoot > 0)
                {
                    print("Masuk - | angle:" + towerangle.angleShoot);
                    animator.runtimeAnimatorController = Resources.Load("Animation/BasicTowerAnimation/Stand/Front/NormalTowerFront") as RuntimeAnimatorController;
                }
                    
            }
            else
            {
                print("Tower  null");
            }

        }

    }
}
