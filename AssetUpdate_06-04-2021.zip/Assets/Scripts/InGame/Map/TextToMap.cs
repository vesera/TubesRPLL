﻿using UnityEngine;
using System.Text.RegularExpressions;
using System.Collections.Generic;

public class TextToMap : MonoBehaviour
{
    public TextMapping[] mappingData;
    public TextAsset mapText;

    private Vector3 currentPosition;
    private Vector3 worldStart;
    public static GameObject startTile;
    public static GameObject endTile;
    public static GameObject border;
    public static List<GameObject> pathTile = new List<GameObject>();
    public static List<GameObject> mapTile = new List<GameObject>();
    private char getChar;

    void Start()
    {
        GenerateMap();
        /*pathTile.Clear();*/
    }


    private void GenerateMap()
    {
        worldStart = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height)); 
        currentPosition = worldStart; 
        string[] rows = Regex.Split(mapText.text, "\r\n|\r|\n");
        pathTile.Clear();
        foreach (string row in rows)
        {
           
            foreach (char c in row)
            {
                foreach (TextMapping tm in mappingData)
                {
                    if (c == tm.character)
                    {
                        getChar = c;
                        if (getChar == 'S')
                        {
                            startTile = Instantiate(tm.prefabs, currentPosition, Quaternion.identity); 

                        }
                        else if (getChar == 'E')
                        {
                            endTile = Instantiate(tm.prefabs, currentPosition, Quaternion.identity);
                        }
                        else if (getChar == 'P')
                        {
                            pathTile.Add(Instantiate(tm.prefabs, currentPosition, Quaternion.identity));
                            
                        }
                        else if (getChar == 'M')
                        {
                            mapTile.Add(Instantiate(tm.prefabs, currentPosition, Quaternion.identity));
                        }
                        else if (getChar == 'B')
                        {
                            border = Instantiate(tm.prefabs, currentPosition, Quaternion.identity);
                        }
                        else if (getChar == 'D')
                        {
                            border = Instantiate(tm.prefabs, currentPosition, Quaternion.identity);
                        }
                        else if (getChar == 'A')
                        {
                            border = Instantiate(tm.prefabs, currentPosition, Quaternion.identity);
                        }
                        currentPosition = new Vector3(++currentPosition.x, currentPosition.y);
                    }

                }

            }
            currentPosition = new Vector3(worldStart.x, --currentPosition.y);
        }
    }
}
