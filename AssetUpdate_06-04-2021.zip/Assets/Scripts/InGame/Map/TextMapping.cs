﻿using UnityEngine;


[System.Serializable]
public class TextMapping 
{
    public char character;
    public GameObject prefabs;
}
