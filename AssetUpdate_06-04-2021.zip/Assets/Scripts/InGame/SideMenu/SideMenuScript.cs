﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SideMenuScript : MonoBehaviour
{
    public GameObject pauseButton;
    [SerializeField]
    private int inputHealth;
    public static int health ;
    [SerializeField]
    private int inputGold;
    public static int gold;
    public static int rounds;
    void Start()
    {
        health = inputHealth;
        gold = inputGold;
    }
    
    
    public static void playerHealth(int damage)
    {
        print("Take Damage");
        health -= damage;
        if (health <= 0)
        {
            FindObjectOfType<GameOver>().EndGame();
        }
        

    }

    public static void getGold(int golds)
    {
        print("Get Gold = " +gold);
        gold += golds;
    }
    public static void useGold(int golds)
    {
        print("use Gold = " + gold);
        gold -= golds;
    }

   
    public void Update()
    {
        Debug.Log("Player Health = " + health +" Gold = "+gold);
        playerHealth(0);
        getGold(0);
        useGold(0);
    }

}
