﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Rounds : MonoBehaviour
{
    public Text  round;
    // Update is called once per frame
    void Update()
    {
        if (SideMenuScript.rounds != null)
        {
            round.text = WaveControl.rounds.ToString();
        }

    }
}
